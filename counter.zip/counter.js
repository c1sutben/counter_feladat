let count = 0;

const counterDisplay = document.getElementById("counter");
const btnDecrement = document.getElementById("btn-decrement");
const btnIncrement = document.getElementById("btn-increment");

const btnDecrement10 = document.querySelectorAll(".btn-large")[0];
const btnIncrement10 = document.querySelectorAll(".btn-large")[1];

function updateDisplay() {
  counterDisplay.textContent = count;
}


btnDecrement.addEventListener("click", () => {
  count -= 1;
  updateDisplay();
});

btnIncrement.addEventListener("click", () => {
  count += 1;
  updateDisplay();
});

btnDecrement10.addEventListener("click", () => {
  count -= 10;
  updateDisplay();
});

btnIncrement10.addEventListener("click", () => {
  count += 10;
  updateDisplay();
});
